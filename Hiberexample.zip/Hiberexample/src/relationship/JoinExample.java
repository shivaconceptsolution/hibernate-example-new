package relationship;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class JoinExample {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
        SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Query q = session.createQuery("select v.vid,v.vname,c.custname from Vendor v inner join v.children c");
	//	Query q = session.createQuery("select v.vid,v.vname,c.custname from Vendor v left join v.children c");
	//	Query q = session.createQuery("select v.vid,v.vname,c.custname from Vendor v right join v.children c");
		List lst = q.list();
		Iterator it = lst.iterator();
		while(it.hasNext())
		{
			 Object arr[] = (Object[])it.next();
			 System.out.println(arr[0] + " ," + arr[1] + " ," +arr[2]);
		}
		session.close();
		factory.close();

	}

}
