package relationship;

import java.util.HashSet;
import java.util.Set;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class OnetoManyLogic {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		//parent object
		Vendor v =new Vendor();

		v.setVid(102);
		v.setVname("Kangaroo");

		//creating 3 child objects
		Customer c1=new Customer();

		c1.setCustid(4);
		c1.setCustname("Santosh");

		Customer c2=new Customer();

		c2.setCustid(5);
		c2.setCustname("Kunal");

		Customer c3=new Customer();

		c3.setCustid(6);
		c3.setCustname("Ravi");

		// adding child objects to set, as we taken 3rd property set in parent
		Set s=new HashSet();

		s.add(c1);
		s.add(c2);
		s.add(c3);

		v.setChildren(s);

		Transaction tx = session.beginTransaction();

		session.save(v);

		tx.commit();
		session.close();
		System.out.println("One To Many is Done..!!");
		factory.close();

	}

}
