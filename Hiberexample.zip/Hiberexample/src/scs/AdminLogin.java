package scs;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import java.util.Scanner;
public class AdminLogin {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Query q = s.createQuery("from Login obj where obj.userid=? and obj.password=?");
	    String uid;
	    String upass;
	    System.out.println("Enter userid");
	    uid = sc.next();
	    System.out.println("Enter password");
	    upass = sc.next();
		q.setString(0,uid);
		q.setString(1,upass);
		List lst = q.list();
		if(lst.size()>0)
			
		{
			System.out.println("Login Successfully");
			EmpOpeartion obj = new EmpOpeartion();
			obj.configureHiber();
			
			System.out.println("Press1 for insert,2 for update, 3 for delete");
			int op = sc.nextInt();
			
			switch(op)
			{
			    case 1:
			
				obj.acceptData();	
				obj.insertHiber(obj.empid,obj.ename,obj.job,obj.salary);
				obj.displayHiber();
				break;
			    case 2:
			    obj.acceptData();	
				obj.updateHiber(obj.empid,obj.ename,obj.job,obj.salary);
				obj.displayHiber();
				break;
			    case 3:
			    	System.out.println("Enter empid");
					int eid = sc.nextInt();
					obj.deleteHiber(eid);
					obj.displayHiber();
					break;
			}
			
			obj.closeConfiguration();

		}
		else
		{
			System.out.println("Invalid userid and password");
		}
		
		s.close();

	}

}
